<?php $__env->startSection('title', '403 - Akses Ditolak'); ?>

<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-lg text-center">
    <div class="rounded-lg border border-slate-200 bg-white p-8 shadow-sm">
        <h1 class="text-6xl font-extrabold text-red-600">403</h1>
        <h2 class="mt-4 text-xl font-bold text-slate-800">Akses ditolak</h2>
        <p class="mt-2 text-sm text-slate-600">
            Anda tidak memiliki hak akses ke halaman atau data ini.
        </p>
        <div class="mt-6">
            <a href="<?php echo e(route('dashboard')); ?>" class="inline-block rounded bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">
                Kembali ke Beranda
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arifinasyikin/kuliah 2026/pemprograman web 20261 upk/pendataan-siswa/resources/views/errors/403.blade.php ENDPATH**/ ?>