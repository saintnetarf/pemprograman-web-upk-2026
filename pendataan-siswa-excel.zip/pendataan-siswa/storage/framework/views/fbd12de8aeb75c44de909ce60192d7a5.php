<?php $__env->startSection('title', 'Kelola Pengguna'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4 flex flex-wrap items-center justify-between gap-3">
    <h1 class="text-2xl font-semibold">Kelola Pengguna</h1>
    <a href="<?php echo e(route('users.create')); ?>"
       class="rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700">
        + Tambah Pengguna
    </a>
</div>

<form method="GET" class="mb-4 flex gap-2">
    <input type="text" name="q" value="<?php echo e($q); ?>"
           placeholder="Cari nama atau email..."
           class="w-full max-w-sm rounded border border-slate-300 px-3 py-2">
    <button class="rounded bg-slate-700 px-4 py-2 text-white">Cari</button>
</form>

<div class="overflow-x-auto rounded border bg-white">
    <table class="min-w-full text-sm">
        <thead class="bg-slate-100 text-left">
            <tr>
                <th class="px-3 py-2">No</th>
                <th class="px-3 py-2">Nama</th>
                <th class="px-3 py-2">Email</th>
                <th class="px-3 py-2">Peran</th>
                <th class="px-3 py-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t">
                    <td class="px-3 py-2"><?php echo e($users->firstItem() + $loop->index); ?></td>
                    <td class="px-3 py-2"><?php echo e($u->name); ?></td>
                    <td class="px-3 py-2"><?php echo e($u->email); ?></td>
                    <td class="px-3 py-2">
                        <span class="inline-flex items-center rounded-full bg-slate-100 px-2 py-0.5 text-xs font-semibold text-slate-800">
                            <?php echo e($u->role->label()); ?>

                        </span>
                    </td>
                    <td class="px-3 py-2">
                        <a href="<?php echo e(route('users.edit', $u)); ?>"
                           class="text-blue-600 hover:underline">Ubah</a>
                        <?php if(! $u->is(auth()->user())): ?>
                            <form action="<?php echo e(route('users.destroy', $u)); ?>" method="POST"
                                  class="ml-2 inline"
                                  onsubmit="return confirm('Hapus pengguna ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="text-red-600 hover:underline">Hapus</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="px-3 py-6 text-center text-slate-500">
                        Belum ada data pengguna.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-4">
    <?php echo e($users->links()); ?>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arifinasyikin/kuliah 2026/pemprograman web 20261 upk/pendataan-siswa/resources/views/users/index.blade.php ENDPATH**/ ?>