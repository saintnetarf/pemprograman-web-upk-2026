<?php $__env->startSection('title', 'Data Siswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4 flex flex-wrap items-center justify-between gap-3">
    <h1 class="text-2xl font-semibold text-slate-800">Data Siswa</h1>
    <div class="flex flex-wrap items-center gap-2">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('import', App\Models\Siswa::class)): ?>
            <a href="<?php echo e(route('siswa.import.create')); ?>"
               class="rounded bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700">
                Import Excel
            </a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('export', App\Models\Siswa::class)): ?>
            <a href="<?php echo e(route('siswa.ekspor.daftar', request()->only('q', 'kelas'))); ?>"
               class="rounded bg-rose-600 px-4 py-2 text-sm font-medium text-white hover:bg-rose-700">
                Ekspor PDF
            </a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\Models\Siswa::class)): ?>
            <a href="<?php echo e(route('siswa.create')); ?>"
               class="rounded bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700">
                + Tambah Siswa
            </a>
        <?php endif; ?>
    </div>
</div>

<form method="GET" class="mb-4 flex flex-wrap gap-2">
    <?php if($pilihanKelas->isNotEmpty()): ?>
        <select name="kelas" class="rounded border border-slate-300 bg-white px-3 py-2 text-sm">
            <option value="">-- Semua Kelas --</option>
            <?php $__currentLoopData = $pilihanKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $namaKelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($id); ?>" <?php if((string) $kelasId === (string) $id): echo 'selected'; endif; ?>>
                    <?php echo e($namaKelas); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    <?php endif; ?>

    <input type="text" name="q" value="<?php echo e($q); ?>"
           placeholder="Cari nama, NIK, atau kecamatan..."
           class="w-full max-w-sm rounded border border-slate-300 px-3 py-2 text-sm">
    <button class="rounded bg-slate-700 px-4 py-2 text-sm text-white hover:bg-slate-800">Cari</button>
</form>

<div class="overflow-x-auto rounded border bg-white">
    <table class="min-w-full text-sm">
        <thead class="bg-slate-100 text-left">
            <tr>
                <th class="px-3 py-2">No</th>
                <th class="px-3 py-2">Nama Lengkap</th>
                <th class="px-3 py-2">Kelas</th>
                <th class="px-3 py-2">NIK</th>
                <th class="px-3 py-2">Kecamatan</th>
                <th class="px-3 py-2">Koordinat (lat, lng)</th>
                <th class="px-3 py-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t">
                    <td class="px-3 py-2"><?php echo e($siswas->firstItem() + $loop->index); ?></td>
                    <td class="px-3 py-2 font-medium"><?php echo e($siswa->nama_lengkap); ?></td>
                    <td class="px-3 py-2"><?php echo e($siswa->kelas?->nama ?? '-'); ?></td>
                    <td class="px-3 py-2 font-mono"><?php echo e($siswa->nik); ?></td>
                    <td class="px-3 py-2"><?php echo e($siswa->kecamatan); ?></td>
                    <td class="px-3 py-2">
                        <?php if($siswa->latitude !== null && $siswa->longitude !== null): ?>
                            <?php echo e($siswa->latitude); ?>, <?php echo e($siswa->longitude); ?>

                        <?php else: ?>
                            <span class="inline-flex items-center rounded bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-800">
                                Belum ada titik
                            </span>
                        <?php endif; ?>
                    </td>
                    <td class="px-3 py-2 whitespace-nowrap">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', $siswa)): ?>
                            <a href="<?php echo e(route('siswa.ekspor.biodata', $siswa)); ?>" target="_blank"
                               class="mr-2 text-rose-600 hover:underline">PDF</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $siswa)): ?>
                            <a href="<?php echo e(route('siswa.edit', $siswa)); ?>"
                               class="text-blue-600 hover:underline">Ubah</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $siswa)): ?>
                            <form action="<?php echo e(route('siswa.destroy', $siswa)); ?>" method="POST"
                                  class="ml-2 inline"
                                  onsubmit="return confirm('Hapus data siswa ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="text-red-600 hover:underline">Hapus</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="px-3 py-6 text-center text-slate-500">
                        Belum ada data siswa.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-4">
    <?php echo e($siswas->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arifinasyikin/kuliah 2026/pemprograman web 20261 upk/pendataan-siswa/resources/views/siswa/index.blade.php ENDPATH**/ ?>