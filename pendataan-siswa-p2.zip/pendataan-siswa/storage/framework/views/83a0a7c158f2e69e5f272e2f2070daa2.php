<?php $__env->startSection('title', 'Ubah Siswa'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="mb-4 text-2xl font-semibold">Ubah Data Siswa</h1>

<form action="<?php echo e(route('siswa.update', $siswa)); ?>" method="POST" class="space-y-6">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <?php echo $__env->make('siswa._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arifinasyikin/kuliah 2026/pemprograman web 20261 upk/pendataan-siswa/resources/views/siswa/edit.blade.php ENDPATH**/ ?>