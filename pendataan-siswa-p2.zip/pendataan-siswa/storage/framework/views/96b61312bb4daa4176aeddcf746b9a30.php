<?php use \App\Models\Siswa; ?>

<fieldset class="rounded border bg-white p-4">
    <legend class="px-2 font-semibold">Data Pribadi Siswa</legend>
    <div class="grid gap-4 md:grid-cols-2">
        <?php if (isset($component)) { $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-input','data' => ['name' => 'nik','label' => 'NIK Siswa (16 digit)','value' => $siswa->nik,'maxlength' => '16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'nik','label' => 'NIK Siswa (16 digit)','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->nik),'maxlength' => '16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $attributes = $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $component = $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-input','data' => ['name' => 'nama_lengkap','label' => 'Nama Lengkap (sesuai akta kelahiran)','value' => $siswa->nama_lengkap]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'nama_lengkap','label' => 'Nama Lengkap (sesuai akta kelahiran)','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->nama_lengkap)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $attributes = $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $component = $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal67ad07a4b593e690d435fee92e6413bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67ad07a4b593e690d435fee92e6413bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-select','data' => ['name' => 'status_dalam_keluarga','label' => 'Status Siswa dalam Keluarga','options' => Siswa::STATUS_KELUARGA,'value' => $siswa->status_dalam_keluarga]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'status_dalam_keluarga','label' => 'Status Siswa dalam Keluarga','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(Siswa::STATUS_KELUARGA),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->status_dalam_keluarga)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67ad07a4b593e690d435fee92e6413bb)): ?>
<?php $attributes = $__attributesOriginal67ad07a4b593e690d435fee92e6413bb; ?>
<?php unset($__attributesOriginal67ad07a4b593e690d435fee92e6413bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67ad07a4b593e690d435fee92e6413bb)): ?>
<?php $component = $__componentOriginal67ad07a4b593e690d435fee92e6413bb; ?>
<?php unset($__componentOriginal67ad07a4b593e690d435fee92e6413bb); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-input','data' => ['name' => 'anak_ke','label' => 'Anak ke-','type' => 'number','min' => '1','value' => $siswa->anak_ke]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'anak_ke','label' => 'Anak ke-','type' => 'number','min' => '1','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->anak_ke)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $attributes = $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $component = $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-input','data' => ['name' => 'jumlah_saudara','label' => 'Jumlah Saudara Kandung','type' => 'number','min' => '0','value' => $siswa->jumlah_saudara]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'jumlah_saudara','label' => 'Jumlah Saudara Kandung','type' => 'number','min' => '0','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->jumlah_saudara)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $attributes = $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $component = $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-input','data' => ['name' => 'no_hp','label' => 'No. HP Siswa (isi "-" jika tidak ada)','value' => $siswa->no_hp]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'no_hp','label' => 'No. HP Siswa (isi "-" jika tidak ada)','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->no_hp)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $attributes = $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $component = $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal1c6d00af60286ce7bbd4e81fd78fbcef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1c6d00af60286ce7bbd4e81fd78fbcef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-yatidak','data' => ['name' => 'pernah_tk','label' => 'Pernah TK/RA','value' => $siswa->pernah_tk]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-yatidak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pernah_tk','label' => 'Pernah TK/RA','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->pernah_tk)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1c6d00af60286ce7bbd4e81fd78fbcef)): ?>
<?php $attributes = $__attributesOriginal1c6d00af60286ce7bbd4e81fd78fbcef; ?>
<?php unset($__attributesOriginal1c6d00af60286ce7bbd4e81fd78fbcef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c6d00af60286ce7bbd4e81fd78fbcef)): ?>
<?php $component = $__componentOriginal1c6d00af60286ce7bbd4e81fd78fbcef; ?>
<?php unset($__componentOriginal1c6d00af60286ce7bbd4e81fd78fbcef); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal1c6d00af60286ce7bbd4e81fd78fbcef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1c6d00af60286ce7bbd4e81fd78fbcef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-yatidak','data' => ['name' => 'pernah_paud','label' => 'Pernah PAUD','value' => $siswa->pernah_paud]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-yatidak'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'pernah_paud','label' => 'Pernah PAUD','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->pernah_paud)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1c6d00af60286ce7bbd4e81fd78fbcef)): ?>
<?php $attributes = $__attributesOriginal1c6d00af60286ce7bbd4e81fd78fbcef; ?>
<?php unset($__attributesOriginal1c6d00af60286ce7bbd4e81fd78fbcef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c6d00af60286ce7bbd4e81fd78fbcef)): ?>
<?php $component = $__componentOriginal1c6d00af60286ce7bbd4e81fd78fbcef; ?>
<?php unset($__componentOriginal1c6d00af60286ce7bbd4e81fd78fbcef); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-input','data' => ['name' => 'hobi','label' => 'Hobi','value' => $siswa->hobi]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'hobi','label' => 'Hobi','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->hobi)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $attributes = $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $component = $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-input','data' => ['name' => 'cita_cita','label' => 'Cita-cita','value' => $siswa->cita_cita]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'cita_cita','label' => 'Cita-cita','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->cita_cita)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $attributes = $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $component = $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
    </div>
</fieldset>

<fieldset class="rounded border bg-white p-4">
    <legend class="px-2 font-semibold">Alamat Tinggal Sekarang</legend>
    <div class="grid gap-4 md:grid-cols-2">
        <div class="md:col-span-2">
            <label for="alamat" class="mb-1 block text-sm font-medium">
                Alamat Lengkap (nomor rumah, RT, dan RW)
            </label>
            <textarea id="alamat" name="alamat" rows="2"
                      class="w-full rounded border border-slate-300 px-3 py-2"><?php echo e(old('alamat', $siswa->alamat)); ?></textarea>
            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <?php if (isset($component)) { $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-input','data' => ['name' => 'kabupaten_kota','label' => 'Kabupaten/Kota','value' => $siswa->kabupaten_kota ?? 'Kota Banjarmasin']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'kabupaten_kota','label' => 'Kabupaten/Kota','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->kabupaten_kota ?? 'Kota Banjarmasin')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $attributes = $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $component = $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-input','data' => ['name' => 'kecamatan','label' => 'Kecamatan','value' => $siswa->kecamatan]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'kecamatan','label' => 'Kecamatan','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->kecamatan)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $attributes = $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $component = $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-input','data' => ['name' => 'kelurahan','label' => 'Kelurahan','value' => $siswa->kelurahan]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'kelurahan','label' => 'Kelurahan','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->kelurahan)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $attributes = $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $component = $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-input','data' => ['name' => 'kode_pos','label' => 'Kode Pos','maxlength' => '5','value' => $siswa->kode_pos]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'kode_pos','label' => 'Kode Pos','maxlength' => '5','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->kode_pos)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $attributes = $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $component = $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal67ad07a4b593e690d435fee92e6413bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67ad07a4b593e690d435fee92e6413bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-select','data' => ['name' => 'status_tinggal','label' => 'Status Tempat Tinggal Sekarang','options' => Siswa::STATUS_TINGGAL,'value' => $siswa->status_tinggal]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'status_tinggal','label' => 'Status Tempat Tinggal Sekarang','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(Siswa::STATUS_TINGGAL),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->status_tinggal)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67ad07a4b593e690d435fee92e6413bb)): ?>
<?php $attributes = $__attributesOriginal67ad07a4b593e690d435fee92e6413bb; ?>
<?php unset($__attributesOriginal67ad07a4b593e690d435fee92e6413bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67ad07a4b593e690d435fee92e6413bb)): ?>
<?php $component = $__componentOriginal67ad07a4b593e690d435fee92e6413bb; ?>
<?php unset($__componentOriginal67ad07a4b593e690d435fee92e6413bb); ?>
<?php endif; ?>
    </div>
</fieldset>

<fieldset class="rounded border bg-white p-4">
    <legend class="px-2 font-semibold">Jarak dan Transportasi ke Sekolah</legend>
    <div class="grid gap-4 md:grid-cols-3">
        <?php if (isset($component)) { $__componentOriginal67ad07a4b593e690d435fee92e6413bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67ad07a4b593e690d435fee92e6413bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-select','data' => ['name' => 'jarak_ke_sekolah','label' => 'Jarak Rumah ke Sekolah','options' => Siswa::JARAK,'value' => $siswa->jarak_ke_sekolah]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'jarak_ke_sekolah','label' => 'Jarak Rumah ke Sekolah','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(Siswa::JARAK),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->jarak_ke_sekolah)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67ad07a4b593e690d435fee92e6413bb)): ?>
<?php $attributes = $__attributesOriginal67ad07a4b593e690d435fee92e6413bb; ?>
<?php unset($__attributesOriginal67ad07a4b593e690d435fee92e6413bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67ad07a4b593e690d435fee92e6413bb)): ?>
<?php $component = $__componentOriginal67ad07a4b593e690d435fee92e6413bb; ?>
<?php unset($__componentOriginal67ad07a4b593e690d435fee92e6413bb); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal67ad07a4b593e690d435fee92e6413bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67ad07a4b593e690d435fee92e6413bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-select','data' => ['name' => 'transportasi','label' => 'Transportasi ke Sekolah','options' => Siswa::TRANSPORTASI,'value' => $siswa->transportasi]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'transportasi','label' => 'Transportasi ke Sekolah','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(Siswa::TRANSPORTASI),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->transportasi)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67ad07a4b593e690d435fee92e6413bb)): ?>
<?php $attributes = $__attributesOriginal67ad07a4b593e690d435fee92e6413bb; ?>
<?php unset($__attributesOriginal67ad07a4b593e690d435fee92e6413bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67ad07a4b593e690d435fee92e6413bb)): ?>
<?php $component = $__componentOriginal67ad07a4b593e690d435fee92e6413bb; ?>
<?php unset($__componentOriginal67ad07a4b593e690d435fee92e6413bb); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal67ad07a4b593e690d435fee92e6413bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal67ad07a4b593e690d435fee92e6413bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-select','data' => ['name' => 'waktu_tempuh','label' => 'Waktu Tempuh ke Sekolah','options' => Siswa::WAKTU_TEMPUH,'value' => $siswa->waktu_tempuh]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'waktu_tempuh','label' => 'Waktu Tempuh ke Sekolah','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(Siswa::WAKTU_TEMPUH),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->waktu_tempuh)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal67ad07a4b593e690d435fee92e6413bb)): ?>
<?php $attributes = $__attributesOriginal67ad07a4b593e690d435fee92e6413bb; ?>
<?php unset($__attributesOriginal67ad07a4b593e690d435fee92e6413bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal67ad07a4b593e690d435fee92e6413bb)): ?>
<?php $component = $__componentOriginal67ad07a4b593e690d435fee92e6413bb; ?>
<?php unset($__componentOriginal67ad07a4b593e690d435fee92e6413bb); ?>
<?php endif; ?>
    </div>
</fieldset>

<fieldset class="rounded border bg-white p-4">
    <legend class="px-2 font-semibold">Titik Koordinat Rumah</legend>
    <p class="mb-2 text-sm text-slate-600">
        Klik pada peta untuk menandai lokasi rumah. Penanda dapat digeser untuk
        menyesuaikan posisi.
    </p>
    <div id="map-picker" class="h-96 rounded border"></div>

    <div class="mt-3 grid gap-4 md:grid-cols-3">
        <?php if (isset($component)) { $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-input','data' => ['name' => 'latitude','label' => 'Latitude (lintang)','type' => 'number','step' => 'any','value' => $siswa->latitude]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'latitude','label' => 'Latitude (lintang)','type' => 'number','step' => 'any','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->latitude)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $attributes = $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $component = $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-input','data' => ['name' => 'longitude','label' => 'Longitude (bujur)','type' => 'number','step' => 'any','value' => $siswa->longitude]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'longitude','label' => 'Longitude (bujur)','type' => 'number','step' => 'any','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->longitude)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $attributes = $__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__attributesOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14)): ?>
<?php $component = $__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14; ?>
<?php unset($__componentOriginal93a7e4fbb8709cb7edbcf616ab99cd14); ?>
<?php endif; ?>
        <div class="flex items-end">
            <button type="button" id="btn-lokasi"
                    class="rounded border border-slate-300 bg-white px-4 py-2 hover:bg-slate-100">
                Gunakan lokasi saya
            </button>
        </div>
    </div>
</fieldset>

<?php if(auth()->user()?->hasRole(\App\Enums\Role::Sekolah)): ?>
    <fieldset class="rounded border p-4">
        <legend class="px-2 font-medium">Kelas dan Penautan Akun</legend>
        <div class="grid grid-cols-1 gap-4 md:grid-cols-3">
            <?php if (isset($component)) { $__componentOriginal47a859ebf4447bf25387ed6557d2f436 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal47a859ebf4447bf25387ed6557d2f436 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-select-relasi','data' => ['name' => 'kelas_id','label' => 'Kelas','options' => $daftarKelas,'value' => $siswa->kelas_id,'placeholder' => '-- Pilih Kelas --']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-select-relasi'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'kelas_id','label' => 'Kelas','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($daftarKelas),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->kelas_id),'placeholder' => '-- Pilih Kelas --']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal47a859ebf4447bf25387ed6557d2f436)): ?>
<?php $attributes = $__attributesOriginal47a859ebf4447bf25387ed6557d2f436; ?>
<?php unset($__attributesOriginal47a859ebf4447bf25387ed6557d2f436); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal47a859ebf4447bf25387ed6557d2f436)): ?>
<?php $component = $__componentOriginal47a859ebf4447bf25387ed6557d2f436; ?>
<?php unset($__componentOriginal47a859ebf4447bf25387ed6557d2f436); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal47a859ebf4447bf25387ed6557d2f436 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal47a859ebf4447bf25387ed6557d2f436 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-select-relasi','data' => ['name' => 'user_id','label' => 'Akun Siswa','options' => $akunSiswa,'value' => $siswa->user_id,'placeholder' => '-- Pilih Akun Siswa --']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-select-relasi'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'user_id','label' => 'Akun Siswa','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($akunSiswa),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->user_id),'placeholder' => '-- Pilih Akun Siswa --']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal47a859ebf4447bf25387ed6557d2f436)): ?>
<?php $attributes = $__attributesOriginal47a859ebf4447bf25387ed6557d2f436; ?>
<?php unset($__attributesOriginal47a859ebf4447bf25387ed6557d2f436); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal47a859ebf4447bf25387ed6557d2f436)): ?>
<?php $component = $__componentOriginal47a859ebf4447bf25387ed6557d2f436; ?>
<?php unset($__componentOriginal47a859ebf4447bf25387ed6557d2f436); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal47a859ebf4447bf25387ed6557d2f436 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal47a859ebf4447bf25387ed6557d2f436 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-select-relasi','data' => ['name' => 'orang_tua_id','label' => 'Akun Orang Tua','options' => $akunOrtu,'value' => $siswa->orang_tua_id,'placeholder' => '-- Pilih Akun Orang Tua --']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-select-relasi'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'orang_tua_id','label' => 'Akun Orang Tua','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($akunOrtu),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siswa->orang_tua_id),'placeholder' => '-- Pilih Akun Orang Tua --']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal47a859ebf4447bf25387ed6557d2f436)): ?>
<?php $attributes = $__attributesOriginal47a859ebf4447bf25387ed6557d2f436; ?>
<?php unset($__attributesOriginal47a859ebf4447bf25387ed6557d2f436); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal47a859ebf4447bf25387ed6557d2f436)): ?>
<?php $component = $__componentOriginal47a859ebf4447bf25387ed6557d2f436; ?>
<?php unset($__componentOriginal47a859ebf4447bf25387ed6557d2f436); ?>
<?php endif; ?>
        </div>
    </fieldset>
<?php endif; ?>

<div class="flex gap-3">
    <button type="submit"
            class="rounded bg-blue-600 px-5 py-2 text-white hover:bg-blue-700">Simpan</button>
    <a href="<?php echo e(route('siswa.index')); ?>"
       class="rounded border border-slate-300 bg-white px-5 py-2 hover:bg-slate-100">Batal</a>
</div>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const latInput = document.getElementById('latitude');
            const lngInput = document.getElementById('longitude');
            const pusatDefault = [-3.3194, 114.5908]; // Banjarmasin

            const adaKoordinat = latInput.value !== '' && lngInput.value !== '';
            const awal = adaKoordinat
                ? [parseFloat(latInput.value), parseFloat(lngInput.value)]
                : pusatDefault;

            // 1. Membuat peta dan lapisan dasar OpenStreetMap
            const map = L.map('map-picker').setView(awal, adaKoordinat ? 17 : 12);
            L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(map);

            // 2. Fungsi mengisi input lintang dan bujur
            let marker = null;

            function isiInput(lat, lng) {
                latInput.value = lat.toFixed(7);
                lngInput.value = lng.toFixed(7);
            }

            // 3. Fungsi menaruh atau memindahkan marker
            function taruhMarker(lat, lng) {
                if (marker) {
                    marker.setLatLng([lat, lng]);
                    return;
                }
                marker = L.marker([lat, lng], { draggable: true }).addTo(map);
                marker.on('dragend', () => {
                    const p = marker.getLatLng();
                    isiInput(p.lat, p.lng);
                });
            }

            if (adaKoordinat) {
                taruhMarker(awal[0], awal[1]);
            }

            // 4. Klik pada peta menentukan titik rumah
            map.on('click', (e) => {
                taruhMarker(e.latlng.lat, e.latlng.lng);
                isiInput(e.latlng.lat, e.latlng.lng);
            });

            // 5. Jika koordinat diketik manual, marker mengikuti
            [latInput, lngInput].forEach((el) => {
                el.addEventListener('change', () => {
                    const lat = parseFloat(latInput.value);
                    const lng = parseFloat(lngInput.value);
                    if (!isNaN(lat) && !isNaN(lng)) {
                        taruhMarker(lat, lng);
                        map.setView([lat, lng], 17);
                    }
                });
            });

            // 6. Tombol "Gunakan lokasi saya" (memakai GPS atau jaringan perangkat)
            document.getElementById('btn-lokasi').addEventListener('click', () => {
                if (!navigator.geolocation) {
                    alert('Peramban tidak mendukung geolokasi.');
                    return;
                }
                navigator.geolocation.getCurrentPosition(
                    (pos) => {
                        const { latitude, longitude } = pos.coords;
                        taruhMarker(latitude, longitude);
                        isiInput(latitude, longitude);
                        map.setView([latitude, longitude], 17);
                    },
                    () => alert('Lokasi tidak dapat diambil. Izinkan akses lokasi pada peramban.')
                );
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /Users/arifinasyikin/kuliah 2026/pemprograman web 20261 upk/pendataan-siswa/resources/views/siswa/_form.blade.php ENDPATH**/ ?>