<?php use \App\Enums\Role; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Pendataan Siswa'); ?> - SIG Pendataan Siswa</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="bg-slate-50 text-slate-800">
    <header class="border-b bg-white">
        <div class="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
            <a href="<?php echo e(url('/')); ?>" class="text-lg font-semibold text-slate-800">
                SIG Pendataan Siswa SMA
            </a>
            <nav class="flex items-center gap-4 text-sm">
                <?php if(auth()->guard()->check()): ?>
                    <?php ($user = auth()->user()); ?>
                    <a href="<?php echo e(route('dashboard')); ?>" class="hover:text-blue-600">Beranda</a>

                    
                    <?php if($user->hasRole(Role::Sekolah, Role::WaliKelas, Role::OrangTua, Role::Siswa)): ?>
                        <a href="<?php echo e(route('peta')); ?>" class="hover:text-blue-600">Peta</a>
                    <?php endif; ?>

                    <?php if($user->hasRole(Role::Sekolah, Role::WaliKelas, Role::OrangTua)): ?>
                        <a href="<?php echo e(route('siswa.index')); ?>" class="hover:text-blue-600">Data Siswa</a>
                    <?php endif; ?>

                    <?php if($user->hasRole(Role::Siswa)): ?>
                        <a href="<?php echo e(route('profil')); ?>" class="hover:text-blue-600">Profil Saya</a>
                    <?php endif; ?>

                    <?php if($user->hasRole(Role::Sekolah)): ?>
                        <a href="<?php echo e(route('kelas.index')); ?>" class="hover:text-blue-600">Kelas</a>
                    <?php endif; ?>

                    <?php if($user->hasRole(Role::Admin)): ?>
                        <a href="<?php echo e(route('users.index')); ?>" class="hover:text-blue-600">Pengguna</a>
                    <?php endif; ?>

                    <div class="ml-4 flex items-center gap-3 border-l border-slate-200 pl-4">
                        <span class="text-slate-600 font-medium">
                            <?php echo e($user->name); ?> <span class="text-xs text-slate-500">(<?php echo e($user->role->label()); ?>)</span>
                        </span>
                        <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="text-red-600 hover:text-red-800 font-medium">
                                Keluar
                            </button>
                        </form>
                    </div>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="hover:text-blue-600 font-medium">Masuk</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <main class="mx-auto max-w-6xl px-4 py-6">
        <?php if(session('success')): ?>
            <div class="mb-4 rounded bg-green-100 px-4 py-2 text-green-800">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="mb-4 rounded bg-red-100 px-4 py-2 text-red-800">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Users/arifinasyikin/kuliah 2026/pemprograman web 20261 upk/pendataan-siswa/resources/views/layouts/app.blade.php ENDPATH**/ ?>