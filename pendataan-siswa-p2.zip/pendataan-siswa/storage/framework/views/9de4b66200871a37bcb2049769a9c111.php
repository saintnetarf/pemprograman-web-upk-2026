<?php $__env->startSection('title', 'Data Kelas'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4 flex flex-wrap items-center justify-between gap-3">
    <h1 class="text-2xl font-semibold">Data Kelas</h1>
    <a href="<?php echo e(route('kelas.create')); ?>"
       class="rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700">
        + Tambah Kelas
    </a>
</div>

<div class="overflow-x-auto rounded border bg-white">
    <table class="min-w-full text-sm">
        <thead class="bg-slate-100 text-left">
            <tr>
                <th class="px-3 py-2">No</th>
                <th class="px-3 py-2">Kelas</th>
                <th class="px-3 py-2">Wali Kelas</th>
                <th class="px-3 py-2">Jumlah Siswa</th>
                <th class="px-3 py-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t">
                    <td class="px-3 py-2"><?php echo e($loop->iteration); ?></td>
                    <td class="px-3 py-2 font-medium"><?php echo e($kelas->nama); ?></td>
                    <td class="px-3 py-2"><?php echo e($kelas->waliKelas?->name ?? '-'); ?></td>
                    <td class="px-3 py-2"><?php echo e($kelas->siswas_count); ?> siswa</td>
                    <td class="px-3 py-2">
                        <a href="<?php echo e(route('kelas.edit', $kelas)); ?>"
                           class="text-blue-600 hover:underline">Ubah</a>
                        <form action="<?php echo e(route('kelas.destroy', $kelas)); ?>" method="POST"
                              class="ml-2 inline"
                              onsubmit="return confirm('Hapus kelas ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="text-red-600 hover:underline">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="px-3 py-6 text-center text-slate-500">
                        Belum ada data kelas.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arifinasyikin/kuliah 2026/pemprograman web 20261 upk/pendataan-siswa/resources/views/kelas/index.blade.php ENDPATH**/ ?>