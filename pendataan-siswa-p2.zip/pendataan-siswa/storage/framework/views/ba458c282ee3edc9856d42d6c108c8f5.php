<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <div class="rounded-lg border border-slate-200 bg-white p-6 shadow-sm">
        <h1 class="text-2xl font-bold text-slate-800">
            Selamat datang, <?php echo e($user->name); ?>!
        </h1>
        <p class="mt-1 text-sm text-slate-600">
            Anda masuk sebagai <span class="inline-flex items-center rounded-full bg-blue-100 px-2.5 py-0.5 text-xs font-semibold text-blue-800"><?php echo e($user->role->label()); ?></span>.
        </p>

        <div class="mt-6 border-t border-slate-200 pt-4">
            <h2 class="text-base font-semibold text-slate-800">Hak Akses Anda:</h2>
            <ul class="mt-2 list-inside list-disc space-y-1 text-sm text-slate-600">
                <?php $__currentLoopData = $hakAkses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($akses); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arifinasyikin/kuliah 2026/pemprograman web 20261 upk/pendataan-siswa/resources/views/dashboard.blade.php ENDPATH**/ ?>