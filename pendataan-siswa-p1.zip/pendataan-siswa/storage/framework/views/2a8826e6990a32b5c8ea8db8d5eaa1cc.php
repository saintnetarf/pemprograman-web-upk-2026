<?php $__env->startSection('title', 'Data Siswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4 flex flex-wrap items-center justify-between gap-3">
    <h1 class="text-2xl font-semibold">Data Siswa</h1>
    <a href="<?php echo e(route('siswa.create')); ?>"
       class="rounded bg-blue-600 px-4 py-2 text-white hover:bg-blue-700">
        + Tambah Siswa
    </a>
</div>

<form method="GET" class="mb-4 flex gap-2">
    <input type="text" name="q" value="<?php echo e($q); ?>"
           placeholder="Cari nama, NIK, atau kecamatan..."
           class="w-full max-w-sm rounded border border-slate-300 px-3 py-2">
    <button class="rounded bg-slate-700 px-4 py-2 text-white">Cari</button>
</form>

<div class="overflow-x-auto rounded border bg-white">
    <table class="min-w-full text-sm">
        <thead class="bg-slate-100 text-left">
            <tr>
                <th class="px-3 py-2">No</th>
                <th class="px-3 py-2">Nama Lengkap</th>
                <th class="px-3 py-2">NIK</th>
                <th class="px-3 py-2">Kecamatan</th>
                <th class="px-3 py-2">Koordinat (lat, lng)</th>
                <th class="px-3 py-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t">
                    <td class="px-3 py-2"><?php echo e($siswas->firstItem() + $loop->index); ?></td>
                    <td class="px-3 py-2"><?php echo e($siswa->nama_lengkap); ?></td>
                    <td class="px-3 py-2"><?php echo e($siswa->nik); ?></td>
                    <td class="px-3 py-2"><?php echo e($siswa->kecamatan); ?></td>
                    <td class="px-3 py-2"><?php echo e($siswa->latitude); ?>, <?php echo e($siswa->longitude); ?></td>
                    <td class="px-3 py-2">
                        <a href="<?php echo e(route('siswa.edit', $siswa)); ?>"
                           class="text-blue-600 hover:underline">Ubah</a>
                        <form action="<?php echo e(route('siswa.destroy', $siswa)); ?>" method="POST"
                              class="ml-2 inline"
                              onsubmit="return confirm('Hapus data siswa ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="text-red-600 hover:underline">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="px-3 py-6 text-center text-slate-500">
                        Belum ada data siswa.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-4">
    <?php echo e($siswas->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arifinasyikin/kuliah 2026/pemprograman web 20261 upk/pendataan-siswa/resources/views/siswa/index.blade.php ENDPATH**/ ?>