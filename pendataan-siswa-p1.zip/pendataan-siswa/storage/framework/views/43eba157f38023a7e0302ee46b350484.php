<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Pendataan Siswa'); ?> - SIG Pendataan Siswa</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="bg-slate-50 text-slate-800">
    <header class="border-b bg-white">
        <div class="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
            <a href="<?php echo e(route('peta')); ?>" class="text-lg font-semibold">
                SIG Pendataan Siswa SMA
            </a>
            <nav class="flex gap-4 text-sm">
                <a href="<?php echo e(route('peta')); ?>" class="hover:text-blue-600">Peta</a>
                <a href="<?php echo e(route('siswa.index')); ?>" class="hover:text-blue-600">
                    Data Siswa (Admin)
                </a>
            </nav>
        </div>
    </header>

    <main class="mx-auto max-w-6xl px-4 py-6">
        <?php if(session('success')): ?>
            <div class="mb-4 rounded bg-green-100 px-4 py-2 text-green-800">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Users/arifinasyikin/kuliah 2026/pemprograman web 20261 upk/pendataan-siswa/resources/views/layouts/app.blade.php ENDPATH**/ ?>